// Add event listeners
document.addEventListener('DOMContentLoaded', () => {
    const addToCartButtons = document.querySelectorAll('.add-to-cart');
    addToCartButtons.forEach(button => {
        button.addEventListener('click', addToCart);
    });
});

function addToCart() {
    const product = this.parentElement;
    const productName = product.querySelector('h3').textContent;
    const productPrice = parseFloat(product.querySelector('p').textContent.replace('Price: $', ''));
    
    const cartItems = document.querySelector('#cart-items');
    const cartTotal = document.querySelector('#cart-total');

    const listItem = document.createElement('li');
    listItem.textContent = `${productName} - $${productPrice.toFixed(2)}`;
    cartItems.appendChild(listItem);

    const currentTotal = parseFloat(cartTotal.textContent);
    cartTotal.textContent = (currentTotal + productPrice).toFixed(2);
}
